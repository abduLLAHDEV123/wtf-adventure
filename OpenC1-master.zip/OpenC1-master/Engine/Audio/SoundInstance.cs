﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OneAmEngine.Audio
{
    class SoundInstance
    {
        public ISound Sound;
        public float RemainingDuration;
    }
}
