﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OpenC1
{
    class RotatingCamera
    {
    }
}
