﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;

namespace OpenC1
{
    class Checkpoint
    {
        public int Number;
        public BoundingBox BBox;
    }
}
